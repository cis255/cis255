// Dominic Scola
//CS216
//HW 4 Part 2

#include <iostream>
#include <string>

using namespace std;

class node
{
    public:
    node * next;
    int id;
    string first;
    string lastName;
};

//Pre: There is data and the node is empty
//Post: The value returns true if empty, false if not
bool isEmpty(node *head)
{
    if (head==NULL)
    return true;
    else 
    return false;
    };
    
//Pre: There is a node class declared, and input is grabbed from user
//Post: The first node is inserted into the linked list at position 1    
void insertFirst(node *&head, node *&last, int id, string first, string lastName)
{
    node *temp = new node;
    temp -> id = id;
    temp -> first = first;
    temp -> lastName = lastName;
    temp -> next = NULL;
    head = temp;
    last = temp;
    };
//Pre: There is a node class declared and input is grabbed from the user
//Post: The node is inserted into the next part of the node   
void insert(node *&head, node *&last, int id, string first, string lastName)
{
    if(isEmpty(head))
    insertFirst(head, last, id, first, lastName);
   else 
   {
    node *temp = new node;
    temp -> id = id;
    temp -> first = first;
    temp -> lastName = lastName;
    temp -> next = NULL;
    last -> next = temp;
    last = temp;
   }
};
//Pre: There is data in the linked list and at least one node
//Post: The first node is removed from the linked list
class node *remove(node *head, node *&last)
{
    if(isEmpty(head))
    {
    cout << "The linked list is empty" << endl;
    return head;
    }
    else if (head == last)
    { delete head;
    head == NULL;
    last == NULL;
    cout << "Deleted" << endl;
    return head;
    }
    else 
    {
        node *temp = head;
        head = head -> next;
        delete temp;
        cout << "Deleted" << endl;
        return head;
    }
    
};
//Pre: None
//Post: The values found in the node are output to the console.
void display (node *current)
{
     int count = 1;
    if(isEmpty(current))
    {
        cout << "This list is empty" << endl;
    }
    
    else
    {
        cout << "The list contains: " << endl;
        while (current != NULL)
        {
            cout << "Position " << count << "." << endl;
            cout << current ->id << endl;
            cout << current -> first << endl;
            cout << current -> lastName << endl << endl;
            
            current = current ->next;
            count++;
        }
    }
};
//Pre: There is data in the linked list to search
//Post: The node pointer returns to the value searched if found, or the head of the node if not
class node * search(int num, node * head)
{
int flag = 0;
class node *temp;

temp = head;

  while(temp!=NULL)
  {
    if(temp->id == num)
    {
    cout << "Found!" << endl;
       return(temp); //Found
    }
    temp = temp->next;
  }

  if(flag == 0)
  cout << "ERROR NOT FOUND" << endl;
     return(head); // Not found
}


//Begin main
int main()
{
    
    //Declare nodes for head and last
    node *head = NULL;
    node *last =NULL;
    
    //Input variables declared
    int id;
    string first;
    string lastName;
    int choice =0;
    
    //Loop the menu
    do
    {
    cout <<"Menu: " << endl;
    cout << "1. Insert item" << endl;
    cout << "2. Delete item" << endl;
    cout << "3. Display list" << endl;
    cout << "4. Search List" << endl;
    cout << "5. Exit Program" << endl;
    
    cin >> choice;
    
    //Switch based on user input, and call functions based on the selection made by user
    switch(choice)
    {
    {
        //Case for insert function          
        case 1:
        cout << "Enter Id number: ";
        cin >> id;
        cout << "Enter first name: ";
        cin >> first;
        cout << "Enter last name: ";
        cin >> lastName;
        insert(head, last, id, first, lastName);
        break;
        
    }
        //Case for removing an option from the linked list
        case 2:
        {
            head = remove(head, last);
        break;
        }
        
        //case for displaying the values in the linked list
        case 3:
        {
        display(head);
        break;
        }
        //case for searching through the array
        case 4:
        {
             node *searched = NULL;
            int searchID;
            cout << "What id would you like to search?" << endl;
            cin >> searchID;
            searched = search(searchID, head);
            cout << endl << searched -> id << endl;
            cout << searched -> first << endl;
            cout << searched -> lastName << endl;
            break;
        }
        //case for exiting the program
        case 5: cout <<"Goodbye!" << endl;
        break;
        default: cout <<"Invalid choice. Please make a valid selection" << endl;
    
    }
    } while (choice !=5);
    system("pause");
    return 0;
    
}
