//Dominic Scola
//CS216
//HW 4 Problem 1

#include <iostream>

using namespace std;

int main ()
{
    //Get size of array from user
    int size;
    cout << "How many numbers? ";
    cin >> size;
    
    //dynamically declare the array
    int *ptr;
    ptr = new int[size];
    int total =0;
    cout << "Enter " << size << " numbers " << endl;
    
    //Enter the user's input into the array and total them
    for(int i=0; i <size; i++)
    {
             cin >> *ptr;
             total = total + *ptr;
    }   
    //Output
    cout << "Sum is: " << total << endl;
    system("pause");   
    return 0;
}
